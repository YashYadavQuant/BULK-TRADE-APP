# Market Ledger — UI upgrade

Replace the existing `app.py` and `requirements.txt` with these files to upgrade the UI. This version keeps the app in one file, so no `app.sources` module is required. No sample trade data is included.

In Streamlit Community Cloud, keep Main file path set to `app.py`.

The optional `.streamlit/config.toml` file can be copied into the same path in your repository.
